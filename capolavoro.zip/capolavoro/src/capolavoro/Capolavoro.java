
package capolavoro;

import java.util.Scanner;
import java.util.Random;


public class Capolavoro {
    
    private static final String[] domandeFacili = {
        "Qual è il videogioco più venduto di tutti i tempi?",
        "\"Finish Him!\" è la frase iconica di quale brutale serie di combattimenti?",
        "chi è il protagonista della serie di giochi: God Of War?",
        "Qual è il nome del videogioco che ha introdotto il personaggio Master Chief?",
        "Quale console è stata la prima ad essere prodotta da Sony?"
    };
    private static final String[] domandeMedie = {
        
        "In quale videogioco la protagonista è una giovane avventuriera di nome Aloy?",
        "Arthur Morgan è il protagonista di quale gioco?",
        "Quale gioco ha vinto il GOTY nel 2018?",
        "come si chiama il personaggio più iconico dela serie di giochi: Assassin's Creed?",
        "in quale anno è stato rilasciato il primo call of duty?",
    };
    private static final String[] domandeDifficili = {
        "in quale videogioco fu stato introdotto per la prima volta il termine \"easter egg\"?",
        "Qual è il videogioco considerato il primo \"shooter in prima persona\" della storia?",
        "Qual'è stato il primo videogioco creato?",
        "qual'è ststo il primo videogioco platform?",
        "In che anno Super Mario Bros vinse il Game Of The Year?",
    };
    
     private static final String[] risposteFacili = {
        "Minecraft",
        "Mortal Kombat",
        "Kratos",
        "Halo",
        "PlayStation"
    };
      private static final String[] risposteMedie = {
       
        "Horizon zero dawn",
        "Red Dead Redemption 2",
        "God of War(2018)",
        "Ezio Auditore da Firenze",
        "2003",
              
    };
       private static final String[] risposteDifficili = {
        "Adventure",
        "Maze War",
        "Pong",
        "Donkey Kong",
        "1985",
    };

    public static void main(String[] args) {
       
       Scanner ts = new Scanner(System.in);
       Random rand = new Random();
       char risposta1 = 0;
       char risposta2;
       int punteggio = 0;
       
       System.out.println("CAPOLAVORO"); 
        
       do{
            
           
        System.out.println("------------------------");
        System.out.println("Lista dei giochi:");
        System.out.println("1) Sasso, Carta, Forbice");
        System.out.println("2) quiz sui videogiochi");
        System.out.println("------------------------");
        System.out.print("fai la tua scelta: ");
        int scelta = ts.nextInt();
        
     
        System.out.print("\n");
           
           
        switch(scelta){
            
            case 1 :  ts.nextLine();
                      System.out.println("------------------------");
                      System.out.println("BENVENUTO!");
                      System.out.print("Scegli tra sasso, carta o forbice: ");

                      String sceltaUtente = ts.nextLine().toLowerCase();
                      
                       while (!sceltaUtente.equals("sasso") && !sceltaUtente.equals("carta") && !sceltaUtente.equals("forbice")) {
                            System.out.print("Scelta non valida. Riprova: ");
                            sceltaUtente = ts.nextLine().toLowerCase();
                        }
                       
                      int sceltaComputer = rand.nextInt(3);
                      
                      System.out.print("Il computer ha scelto: ");
                      
                      switch(sceltaComputer){
                          case 0: System.out.println("sasso");
                          break;
                          case 1 : System.out.println("carta");
                          break;
                          case 2 : System.out.println("forbice");
                          break;
                      }

                      

                      if (sceltaUtente.equals("sasso") && sceltaComputer == 2 ||
                          sceltaUtente.equals("carta") && sceltaComputer == 0 ||
                          sceltaUtente.equals("forbice") && sceltaComputer == 1) {
                          System.out.println("Hai vinto!");
                    } else if (sceltaUtente.equals("sasso") && sceltaComputer == 1 ||
                               sceltaUtente.equals("carta") && sceltaComputer == 2 ||
                               sceltaUtente.equals("forbice") && sceltaComputer == 0) {
                               System.out.println("Hai perso!");
                               } else {
                               System.out.println("Pareggio!");
                               }
                    break;        
            
            case 2:    System.out.println("------------------------");
            
                       System.out.println("Benvenuto al quiz sui videogiochi!");  

                       do{
                       System.out.println("--------------");
                       System.out.println("1) FACILE");
                       System.out.println("2) MEDIO");
                       System.out.println("3) DIFFICILE");
                       System.out.println("--------------");
                       System.out.print("Scegli un livello di difficoltà: ");
                       int scelta2 = ts.nextInt();
                       
                      
                           
                       
                        switch(scelta2){
                                        
                           case 1 :         ts.nextLine();
                           
                                             for (int i = 0; i < domandeFacili.length; i++) {
                                                 
                                             System.out.println("\nDomanda " + (i + 1) + ": " + domandeFacili[i]);
                                             
                                             System.out.println("------------------------");
                                             
                                             System.out.print("Risposta: ");
                                              
                                             String rispostaUtente = ts.nextLine();
                                             
                                                switch (i) {
                                                    case 0:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteFacili[0])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteFacili[0]);
                                                                }
                                                                break;
                                                    case 1:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteFacili[1])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteFacili[1]);
                                                                }
                                                                break;
                                                     case 2:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteFacili[2])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteFacili[2]);
                                                                }
                                                                break;
                                                    case 3:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteFacili[3])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteFacili[3]);
                                                                }
                                                                break;
                                                                        
                                                    case 4:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteFacili[4])) {
                                                            System.out.println("Esatto!");
                                                            punteggio++;
                                                            } else {
                                                            System.out.println("Sbagliato! La risposta corretta era: " + risposteFacili[4]);
                                                            }
                                                            break;
                                                    default:
                                                            System.out.println("Qualcosa è andato storto!");
                                            }
                                             
                                        }
                                             
                                             
                                       break;
                                          
                                    
                           case 2:          ts.nextLine();
                           
                                             for (int i = 0; i < domandeMedie.length; i++) {
                                                 
                                             System.out.println("\nDomanda " + (i + 1) + ": " + domandeMedie[i]);
                                             
                                              System.out.println("------------------------");
                                             
                                             System.out.print("Risposta: ");
                                              
                                             String rispostaUtente = ts.nextLine();
                                             
                                                switch (i) {
                                                    case 0:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteMedie[0])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteMedie[0]);
                                                                }
                                                                break;
                                                    case 1:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteMedie[1])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteMedie[1]);
                                                                }
                                                                break;
                                                     case 2:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteMedie[2])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteMedie[2]);
                                                                }
                                                                break;
                                                    case 3:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteMedie[3])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteMedie[3]);
                                                                }
                                                                break;
                                                    case 4:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteMedie[4])) {
                                                            System.out.println("Esatto!");
                                                            punteggio++;
                                                            } else {
                                                            System.out.println("Sbagliato! La risposta corretta era: " + risposteMedie[4]);
                                                            }
                                                            break;
                                                    default:
                                                            System.out.println("Qualcosa è andato storto!");
                                            }
                                                 
                                        }
                                             
                                             
                                       break;
                                       
                            case 3:          ts.nextLine();
                           
                                             for (int i = 0; i < domandeDifficili.length; i++) {
                                                 
                                             System.out.println("\nDomanda " + (i + 1) + ": " + domandeDifficili[i]);
                                             
                                              System.out.println("------------------------");
                                             
                                             System.out.print("Risposta: ");
                                              
                                             String rispostaUtente = ts.nextLine();
                                             
                                                switch (i) {
                                                    case 0:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteDifficili[0])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteDifficili[0]);
                                                                }
                                                                break;
                                                    case 1:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteDifficili[1])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteDifficili[1]);
                                                                }
                                                                break;
                                                     case 2:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteDifficili[2])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteDifficili[2]);
                                                                }
                                                                break;
                                                    case 3:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteDifficili[3])) {
                                                                System.out.println("Esatto!");
                                                                punteggio++;
                                                                } else {
                                                                System.out.println("Sbagliato! La risposta corretta era: " + risposteDifficili[3]);
                                                                }
                                                                break;
                                                    case 4:
                                                            if (rispostaUtente.equalsIgnoreCase(risposteDifficili[4])) {
                                                            System.out.println("Esatto!");
                                                            punteggio++;
                                                            } else {
                                                            System.out.println("Sbagliato! La risposta corretta era: " + risposteDifficili[4]);
                                                            }
                                                            break;
                                                    default:
                                                            System.out.println("Qualcosa è andato storto!");
                                            }
                                             
                                        }
                                             
                                             
                                       break;           
                             
                        }
                        System.out.println("hai risposto corettamente a " + punteggio + " domande");
                           System.out.println(" ");   
                           
                     System.out.print("Vuoi riscegliere una difficoltà? (s/n): ");
                     risposta2 = ts.next().charAt(0);
                     
                    }while(risposta2 == 's' || risposta2 == 'S'); 
    
               
        } 
        
         
         System.out.println("------------------------");
         System.out.print("Vuoi risciegliere un gioco? (s/n): ");
         risposta1 = ts.next().charAt(0);
         
       }while(risposta1 == 's' || risposta1 == 'S');
        
        
        
        
        
        
        
        
        
    }
       
    
    

}


